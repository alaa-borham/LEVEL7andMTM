/** Build isolated two-part QA fixture with an original 112 inheritance edge. */
import{parseMdl,serializeMdl}from'./LEVEL7-CAD-0.9.111-source/src/native-mdl.js';import{replaceOriginalBlocks}from'./LEVEL7-CAD-0.9.111-source/src/original-geometry-edit.mjs';
const v=b=>new DataView(b.buffer,b.byteOffset,b.byteLength),cat=xs=>{const out=new Uint8Array(xs.reduce((n,b)=>n+b.length,0));let at=0;for(const b of xs){out.set(b,at);at+=b.length;}return out;},checksum=b=>{let n=0;for(let i=4;i<b.length;i+=2){n=(n+Math.imul(i/2+1,v(b).getInt16(i,true)))|0;if(n>=1024000000)n-=1024000000;}return n>>>0;},block=(id,p)=>{const b=new Uint8Array(32+p.length);v(b).setUint32(4,b.length/8,true);b.set(new TextEncoder().encode('BLO5kenn'),8);id.forEach((n,i)=>v(b).setUint32(16+4*i,n,true));b.set(p,32);v(b).setUint32(0,checksum(b),true);return b;};
export function makeInheritedFixture(base,sourceId,objectClass=2){
 const one=k=>{const b=base.blocks.find(b=>b.id.join('.')===k);if(!b)throw Error(k);return serializeMdl(base).slice(b.payloadOffset,b.endOffset);},header=one('3.1.1.0');v(header).setUint32(0,2,true);v(header).setUint32(8,5,true);v(header).setUint32(20,8,true);v(header).setUint32(36,0,true);header[83]^=1;const identity=[...header.subarray(76,84)].map(n=>n.toString(16).padStart(2,'0')).join('').toUpperCase(),history=new Uint8Array(64);[[112,101,1,0,1,sourceId,objectClass,2001],[112,103,1,8]].forEach((a,i)=>a.forEach((n,j)=>v(history).setUint16(i*32+j*2,n,true)));
 const cache=one('3.1.7.1'),n=v(cache).getUint32(0,true);let at=8+40*n,childCache;for(let i=0;i<n;i++){const row=cache.slice(8+i*40,48+i*40),size=(v(row).getUint32(4,true)+v(row).getUint32(12,true))*8;if(v(row).getUint32(0,true)===sourceId){childCache=cat([new Uint8Array(8),row,cache.slice(at,at+size)]);v(childCache).setUint32(0,1,true);v(childCache).setUint32(4,childCache.length/8,true);v(childCache).setUint32(8,2001,true);}at+=size;}if(!childCache)throw Error('Missing inherited cache');
 if(base.blocks.some(b=>b.id[0]===3&&b.id[1]===2)){
  const existing=one('3.2.1.0');if(existing.length!==152||one('3.2.2.0').length!==64||v(one('3.2.7.1')).getUint32(0,true)!==1)throw Error('Unsupported existing QA child');
  v(existing).setUint32(8,5,true);v(existing).setUint32(20,8,true);v(existing).setUint32(36,0,true);
  return replaceOriginalBlocks(base,new Map([['3.2.1.0',existing],['3.2.2.0',history],['3.2.4.0',new Uint8Array()],['3.2.7.1',childCache]]));
 }
 const text=String.fromCharCode(...one('2.1.0.0')).replace(/\0+$/,''),start=text.indexOf('#TLIST\r\n')+8,end=text.indexOf('\r\n',start),row=text.slice(start,end),child=row.slice(0,3)+'002'+row.slice(6,32)+'    2'+'   1'+row.slice(41).replace(/ID=[A-F0-9]+/,'ID='+identity),listText=text.slice(0,end)+'\r\n'+child+text.slice(end),list=new Uint8Array(Math.ceil(listText.length/8)*8);list.set(Uint8Array.from(listText,c=>c.charCodeAt(0)));const parent=replaceOriginalBlocks(base,new Map([['2.1.0.0',list]])),bytes=serializeMdl(parent),joined=cat([bytes.subarray(0,-8),block([3,2,1,0],header),block([3,2,2,0],history),block([3,2,4,0],new Uint8Array()),block([3,2,5,0],new Uint8Array()),block([3,2,7,1],childCache),bytes.subarray(-8)]);v(joined).setUint32(4,(joined.length-8)/8,true);v(joined).setUint32(0,checksum(joined.subarray(0,80)),true);return parseMdl(joined);
}

/** Isolated third-part fixture for checking edits to a linked destination. */
export function makeThirdFixture(base,sourceId,objectClass=2){
 if(base.blocks.some(b=>b.id[0]===3&&b.id[1]===3))throw Error('Third QA part exists');const bytes=serializeMdl(base),one=k=>{const b=base.blocks.find(b=>b.id.join('.')===k);if(!b)throw Error(k);return bytes.slice(b.payloadOffset,b.endOffset);},header=one('3.2.1.0');v(header).setUint32(0,3,true);v(header).setUint32(8,5,true);v(header).setUint32(20,8,true);v(header).setUint32(36,0,true);header[83]^=3;const identity=[...header.subarray(76,84)].map(n=>n.toString(16).padStart(2,'0')).join('').toUpperCase(),history=new Uint8Array(64);[[112,101,1,0,2,sourceId,objectClass,2001],[112,103,1,8]].forEach((a,i)=>a.forEach((n,j)=>v(history).setUint16(i*32+j*2,n,true)));
 const cache=one('3.2.7.1'),n=v(cache).getUint32(0,true);let pool=8+n*40,child;for(let i=0;i<n;i++){const row=cache.slice(8+i*40,48+i*40),size=(v(row).getUint32(4,true)+v(row).getUint32(12,true))*8;if(v(row).getUint32(0,true)===sourceId){child=cat([new Uint8Array(8),row,cache.slice(pool,pool+size)]);v(child).setUint32(0,1,true);v(child).setUint32(4,child.length/8,true);v(child).setUint32(8,2001,true);}pool+=size;}if(!child)throw Error('Missing third-part source cache');
 const text=String.fromCharCode(...one('2.1.0.0')).replace(/\0+$/,''),start=text.indexOf('#TLIST\r\n')+8,end=text.indexOf('\r\n',start),row=text.slice(start,end),line=row.slice(0,3)+'003'+row.slice(6,32)+'    2'+'   1'+row.slice(41).replace(/ID=[A-F0-9]+/,'ID='+identity),listText=text.slice(0,end)+'\r\n'+line+text.slice(end),list=new Uint8Array(Math.ceil(listText.length/8)*8);list.set(Uint8Array.from(listText,c=>c.charCodeAt(0)));const replaced=serializeMdl(replaceOriginalBlocks(base,new Map([['2.1.0.0',list]]))),out=cat([replaced.subarray(0,-8),block([3,3,1,0],header),block([3,3,2,0],history),block([3,3,4,0],new Uint8Array()),block([3,3,5,0],new Uint8Array()),block([3,3,7,1],child),replaced.subarray(-8)]);v(out).setUint32(4,(out.length-8)/8,true);v(out).setUint32(0,checksum(out.subarray(0,80)),true);return parseMdl(out);
}










