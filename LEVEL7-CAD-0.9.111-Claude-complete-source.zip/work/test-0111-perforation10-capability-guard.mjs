import{appendOriginalPerforation10,editOriginalPerforation10}from'./LEVEL7-CAD-0.9.111-source/src/original-perforation10.mjs';
import {readOriginalTextTemplates,PART_NAME_TEXT_FIELD as NAME,PART_NUMBER_TEXT_FIELD as NUMBER} from './LEVEL7-CAD-0.9.111-source/src/native-part-text.mjs';
import fs from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';import{_electron}from'file:///C:/Users/Borham/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import {parseMdl,serializeMdl,getNativeN38TemplateBytes} from './LEVEL7-CAD-0.9.111-source/src/native-mdl.js';import {readCachedPreview} from './LEVEL7-CAD-0.9.111-source/src/native-cache-preview.js';
const source=path.resolve('work/LEVEL7-CAD-0.9.111-source'),input=path.resolve('work/0986-corner-base.mdl'),qa=await fs.mkdtemp(path.resolve('work/0111-seam-ui-')),checks=[],errors=[],pass=x=>{checks.push(x);console.log('PASS '+x);};let app,page;
try{const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;env.LOCALAPPDATA=path.join(qa,'profile');app=await _electron.launch({executablePath:path.resolve('work/desktop-build/node_modules/electron/dist/electron.exe'),args:[source],env,timeout:30000});page=await app.firstWindow();page.setDefaultTimeout(15000);page.on('dialog',d=>d.accept().catch(()=>{}));page.on('pageerror',e=>errors.push(e.message));await page.setViewportSize({width:1500,height:1100});await page.locator('[data-tool-category]').first().waitFor();await app.evaluate(({dialog})=>{global.__qa={opens:[],saves:[]};dialog.showOpenDialog=async()=>global.__qa.opens.shift()??{canceled:true};dialog.showSaveDialog=async()=>global.__qa.saves.shift()??{canceled:true};});
const open=async f=>{await app.evaluate((_e,f)=>global.__qa.opens.push({canceled:false,filePaths:[f]}),f);await page.locator('#cad-toolbox [data-action="open"]').click();await page.waitForFunction(n=>document.querySelector('#document-name').textContent===n,path.basename(f));},save=async n=>{const f=path.join(qa,n);await app.evaluate((_e,f)=>global.__qa.saves.push({canceled:false,filePath:f}),f);await page.locator('#cad-toolbox [data-action="save-as"]').click();await page.waitForFunction(n=>document.querySelector('#document-name').textContent===n,n);return f;};

const pick=async(selector,f=.5,clicks=1)=>{const p=await page.locator(selector).first().evaluate((e,f)=>{const p=e.getPointAtLength(e.getTotalLength()*f),q=new DOMPoint(p.x,p.y).matrixTransform(e.getScreenCTM());return{x:q.x,y:q.y};},f);if(clicks===2)await page.mouse.dblclick(p.x,p.y);else await page.mouse.click(p.x,p.y);};







const result=await page.evaluate(async()=>{const{createPerforation10Ui}=await import('./src/original-perforation10-ui.js');const invalid=new Proxy({},{get(){throw Error('QA unsupported calculation');}}),context={document:invalid,partId:1,sizeKey:'___N38_0',full:true,overview:false,drawing:false,busy:false},ui=createPerforation10Ui({context:()=>context,prepare(){},busy(){},commit(){},scale:()=>1});await new Promise(r=>setTimeout(r,100));const result={opened:ui.open(2001),disabled:document.querySelector('[data-original-perforation10-create]').disabled};ui.close();return result;});assert.deepEqual(result,{opened:false,disabled:true});pass('Unsupported calculation disables creation and double-click returns safely without throwing');
assert.deepEqual(errors,[]);
}catch(e){errors.push(e.stack??String(e));console.log(e.stack??e);if(page)await page.screenshot({path:path.join(qa,'failure.png')}).catch(()=>{});}finally{if(app)await app.evaluate(({BrowserWindow})=>{for(const w of BrowserWindow.getAllWindows())w.webContents.on('will-prevent-unload',e=>e.preventDefault());}).catch(()=>{});if(app)await app.close();}await fs.writeFile('work/0111-perforation10-capability-guard-tests.json',JSON.stringify({passed:!errors.length,checks,errors,qa},null,2));if(errors.length)process.exitCode=1;






